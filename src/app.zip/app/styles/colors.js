export const COLORS = {
    heading: "hsl(206, 48%, 40%)",   // blue
    accent: "hsl(45, 100%, 86%)",   // yellow
    hoveryellow: "hsl(56, 100%, 88%)", //lighter yellow
    text: "hsl(0, 0%, 11%)",        // near black for text
  };
  