"use client";

import { useEffect, useState } from "react";
import supabase from "../../config/supabaseClient";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import ProfileNav from "../ProfileNav";
// import ToolbarActions from "../components/ToolbarActions";
// import InlineRename from "./components/InlineRename";
import { useRouter } from "next/navigation";

export default function SavedCollectionPage() {
  const [collections, setCollections] = useState([]);
  const [selectedCollections, setSelectedCollections] = useState([]);
  const router = useRouter();

  // Load collections on mount
  useEffect(() => {
    const fetchCollections = async () => {
      const { data, error } = await supabase
        .from("outfit_collections")
        .select("id, name, created_at");

      if (error) {
        console.error("Error fetching collections:", error);
        toast.error("Failed to load collections");
      } else {
        setCollections(data || []);
      }
    };
    fetchCollections();
  }, []);

  // Toggle collection selection
  const toggleSelectCollection = (id) => {
    setSelectedCollections((prev) =>
      prev.includes(id) ? prev.filter((cid) => cid !== id) : [...prev, id]
    );
  };

  // Delete selected collections
  const handleDeleteSelected = async () => {
    if (selectedCollections.length === 0) return;
    if (!window.confirm("Delete selected collections?")) return;

    const { error } = await supabase
      .from("outfit_collections")
      .delete()
      .in("id", selectedCollections);

    if (error) {
      console.error(error);
      toast.error("Failed to delete collections");
    } else {
      toast.success("Deleted successfully");
      setCollections((prev) =>
        prev.filter((c) => !selectedCollections.includes(c.id))
      );
      setSelectedCollections([]);
    }
  };

  // Add new collection
  const handleAddCollection = async () => {
    const name = prompt("Enter collection name:");
    if (!name) return;

    const { data, error } = await supabase
      .from("outfit_collections")
      .insert([{ name, created_at: new Date().toISOString() }])
      .select("*")
      .single();

    if (error) {
      console.error(error);
      toast.error("Failed to create collection");
    } else {
      setCollections((prev) => [...prev, data]);
      toast.success("New collection added");
    }
  };

  // Inline rename
  const handleRename = async (id, newName) => {
    const { error } = await supabase
      .from("outfit_collections")
      .update({ name: newName })
      .eq("id", id);

    if (error) {
      console.error("Rename failed:", error);
      toast.error("Rename failed");
    } else {
      setCollections((prev) =>
        prev.map((c) => (c.id === id ? { ...c, name: newName } : c))
      );
    }
  };

  return (
    <section className="bg-heading-hl rounded-3xl p-8 sm:p-12 text-white shadow-sm">
      <ProfileNav />

      <h3 className="text-2xl font-fraunces font-medium mb-6 text-center sm:text-left">
        Saved Collections
      </h3>

      {/* ===== Toolbar ===== */}
      {/* <ToolbarActions
        selectedCount={selectedCollections.length}
        totalCount={collections.length}
        onAdd={handleAddCollection}
        onDelete={handleDeleteSelected}
        onToggleSelectAll={() => {
          if (selectedCollections.length === collections.length) {
            setSelectedCollections([]);
          } else {
            setSelectedCollections(collections.map((c) => c.id));
          }
        }}
      /> */}

      {/* ===== Collection Grid ===== */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6 mt-6">
        {collections.map((collection) => (
          <div
            key={collection.id}
            className={`relative p-5 rounded-xl bg-heading-hd/60 hover:bg-heading-hd transition-all cursor-pointer ${
              selectedCollections.includes(collection.id)
                ? "ring-2 ring-blue-400"
                : ""
            }`}
          >
            {/* Selection Checkbox */}
            <input
              type="checkbox"
              checked={selectedCollections.includes(collection.id)}
              onChange={() => toggleSelectCollection(collection.id)}
              className="absolute top-3 right-3 w-5 h-5 accent-blue-500"
            />

            {/* Name with inline rename */}
            {/* <InlineRename
              text={collection.name}
              onSave={(newName) => handleRename(collection.id, newName)}
              textClass="text-lg font-semibold text-white"
            /> */}

            {/* Outfit count placeholder */}
            <p className="text-sm text-gray-200 mt-2">
              Outfits: (load count later)
            </p>

            {/* Click to navigate */}
            <button
              onClick={() =>
                router.push(`/profile/savedoutfits/${collection.id}`)
              }
              className="mt-4 bg-blue-600 text-white px-4 py-2 rounded-md text-sm hover:bg-blue-700 transition-all"
            >
              View Collection
            </button>
          </div>
        ))}
      </div>

      <ToastContainer position="top-center" autoClose={4000} theme="colored" />
    </section>
  );
}
